package controlador;

import dao.PersonaImpl;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import model.Persona;

@Named(value = "personaC")
@SessionScoped
public class PersonaC implements Serializable {

    private Persona persona;
    private PersonaImpl dao;
    private List<Persona> lstper;

    public PersonaC() {
        persona = new Persona();
        dao = new PersonaImpl();
    }

    @PostConstruct
    public void onInit() {
        try {
            listar();
            listar();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void registrar() {
        try {
            dao.registrar(persona);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro", "Registrado con exito"));
            limpiar();
            listar();
        } catch (Exception e) {
            System.out.println("No registra en con trolador toy triste " + e.getMessage());
        }
    }

    public void modificar() {
        try {
            dao.modificar(persona);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificado", "Mdofiicado con exito"));
            limpiar();
            listar();
        } catch (Exception e) {
            System.out.println("No registra en con trolador toy triste " + e.getMessage());
        }
    }

    public void modificarEstado(Persona per) {
        try {
            per.setESTPER("I");
            dao.modificarEst(per);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Eliminar", "Eliminado con exito"));
            limpiar();
            listar();
        } catch (Exception e) {
            System.out.println("Error en modificarC " + e.getMessage());
        }
    }

    public void eliminar(Integer IDPER) {
//        String sql = "DELETE FROM PERSONA WHERE IDPER=?";
//        try {
//            PreparedStatement ps = this.conectar().prepareStatement(sql);
//            ps.setInt(1, per.getIDPER());
//            ps.executeUpdate();
//            ps.close();
//        } catch (Exception e) {
//            System.out.println("Error en eliminar tabla Persona" + e.getMessage());
//        } finally {
//            this.cerrarCnx();
//        }
    }

    public void listar() {
        try {
            lstper = new ArrayList<>();
            lstper = dao.listar();
        } catch (Exception e) {
        }
    }

    public void limpiar() {
        dao = new PersonaImpl();
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public PersonaImpl getDao() {
        return dao;
    }

    public void setDao(PersonaImpl dao) {
        this.dao = dao;
    }

    public List<Persona> getLstper() {
        return lstper;
    }

    public void setLstper(List<Persona> lstper) {
        this.lstper = lstper;
    }

}
