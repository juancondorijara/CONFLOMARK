package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Persona;

public class PersonaImpl extends Conexion implements ICRUD<Persona> {

    @Override
    public void registrar(Persona per) throws Exception {
        String sql = "INSERT INTO PERSONA"
                + "(NOMPER, APEPER, DIRPER, TELPER, TIPPER, ESTPER)"
                + " VALUES(?,?,?,?,?,?)";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setString(1, per.getNOMPER());
            ps.setString(2, per.getAPEPER());
            ps.setString(3, per.getDIRPER());
            ps.setString(4, per.getTELPER());
            ps.setString(5, per.getTIPPER());
            ps.setString(6, "A");
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("No registra mi tabla" + e.getMessage());
        } finally {
            this.cerrarCnx();
        }
    }

    @Override
    public void modificar(Persona per) throws Exception {
        String sql = "UPDATE PERSONA SET"
                + " NOMPER=?, APEPER=?, DIRPER=?, TELPER=?, TIPPER=?, ESTPER=?"
                + "WHERE IDPER=?";
        try {
            PreparedStatement ps = PersonaImpl.conectar().prepareStatement(sql);
            ps.setString(1, per.getNOMPER());
            ps.setString(2, per.getAPEPER());
            ps.setString(3, per.getDIRPER());
            ps.setString(4, per.getTELPER());
            ps.setString(5, per.getTIPPER());
            ps.setString(6, "A");
            ps.setInt(7, per.getIDPER());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("No modifica mi tabla" + e.getMessage());
        } finally {
            this.cerrarCnx();
        }
    }

    @Override
    public void modificarEst(Persona per) throws Exception {
        String sql = "update Persona set"
                + " ESTPER = 'I' where IDPER=?";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setInt(1, per.getIDPER());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error en Modificar Estado" + e.getMessage());
        } finally {
            this.cerrarCnx();
        }
    }

    @Override
    public void eliminar(Persona gen) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Persona> listar() throws Exception {
        List<Persona> listado = new ArrayList<>();
        Persona per;
        String sql = "SELECT * FROM PERSONA WHERE PERSONA.ESTPER = 'A' ORDER BY NOMPER";
        try {
            Statement st = this.conectar().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                per = new Persona();
                per.setIDPER(rs.getInt("IDPER"));
                per.setNOMPER(rs.getString("NOMPER"));
                per.setAPEPER(rs.getString("APEPER"));
                per.setDIRPER(rs.getString("DIRPER"));
                per.setTELPER(rs.getString("TELPER"));
                per.setTIPPER(rs.getString("TIPPER"));
                per.setESTPER(rs.getString("ESTPER"));
                listado.add(per);
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            System.out.println("Error en la listar tabla persona" + e.getMessage());
        } finally {
            this.cerrarCnx();
        }
        return listado;
    }

}
